import { useCallback, useEffect, useRef, useState } from "react"
import {
  ArrowDown, ArrowRight, ArrowUpRight, Braces, Check,
  CheckCircle2, ChevronDown, CircleHelp, Clock3, Code2, Copy, Download,
  ExternalLink, FileCode2, Fingerprint, Gauge, Layers3,
  LockKeyhole, Menu, RefreshCcw, Shield, ShieldCheck,
  SlidersHorizontal, Sparkles, Terminal, Upload, WandSparkles, X, Zap,
} from "lucide-react"
import { CodeEditor } from "@/components/CodeEditor"
import type { LuaVersion, PresetName, PrometheusLog, PrometheusResult, WorkerRequest, WorkerResponse } from "@/lib/prometheusTypes"

const EXAMPLE_LUA = `-- KersCrypt / Example project
local Config = {
    project = "KersCrypt",
    message = "Built to be protected",
    version = 1.0,
}

local function greet(name)
    local result = Config.message .. ": " .. name
    print(result)
    return result
end

greet("developer")`

const EXAMPLE_ROBLOX = `-- Roblox / Luau example
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local function onPlayerAdded(player)
    print("Welcome to the game, " .. player.Name)
end

for _, player in ipairs(Players:GetPlayers()) do
    onPlayerAdded(player)
end
Players.PlayerAdded:Connect(onPlayerAdded)`

const PRESET_DETAILS: Record<PresetName, { subtitle: string; detail: string; strength: number }> = {
  Minify: { subtitle: "Small & quick", detail: "Compact source with minimal transformation.", strength: 1 },
  Weak: { subtitle: "Light protection", detail: "Lightweight obfuscation for faster builds.", strength: 2 },
  Medium: { subtitle: "Balanced protection", detail: "A good balance of size and transformation.", strength: 3 },
  Strong: { subtitle: "Maximum available", detail: "Prometheus's strongest preset, including VM-based transformations.", strength: 4 },
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`
  return `${(bytes / 1024).toFixed(1)} KB`
}
function randomSeed() {
  const arr = new Uint32Array(1)
  if (typeof crypto !== "undefined" && crypto.getRandomValues) crypto.getRandomValues(arr)
  else arr[0] = Math.floor(Math.random() * 4294967295)
  return (arr[0] % 2147483646) + 1
}
function saveFile(contents: string, name: string) {
  const blob = new Blob([contents], { type: "text/plain;charset=utf-8" })
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = name
  document.body.append(link)
  link.click()
  link.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 1000)
}

function Brand({ onClick }: { onClick?: () => void }) {
  return <a href="#top" onClick={onClick} className="brand" aria-label="KersCrypt home">
    <span className="brand-icon"><Braces size={22} strokeWidth={2.8}/></span>
    <span>Kers<span className="brand-accent">Crypt</span><span className="brand-dot">.</span></span>
  </a>
}

function SmallTag({ children, style = "" }: { children: React.ReactNode; style?: string }) {
  return <span className={`small-tag ${style}`}>{children}</span>
}

const WORKER_TIMEOUT_MS = 120_000

export default function App() {
  const [source, setSource] = useState(EXAMPLE_LUA)
  const [fileName, setFileName] = useState("example.lua")
  const [output, setOutput] = useState("")
  const [preset, setPreset] = useState<PresetName>("Strong")
  const [luaVersion, setLuaVersion] = useState<LuaVersion>("Lua51")
  const [prettyPrint, setPrettyPrint] = useState(false)
  const [seed, setSeed] = useState(randomSeed)
  const [logs, setLogs] = useState<PrometheusLog[]>([])
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">("idle")
  const [message, setMessage] = useState("")
  const [elapsed, setElapsed] = useState(0)
  const [mobileMenu, setMobileMenu] = useState(false)
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [copied, setCopied] = useState(false)
  const [showLog, setShowLog] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const inputFileRef = useRef<HTMLInputElement>(null)
  const workerRef = useRef<Worker | null>(null)
  const rejectRef = useRef<((reason: Error) => void) | null>(null)
  const requestRef = useRef(0)
  const startedRef = useRef(0)
  const runTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const running = status === "running"

  const changeSource = useCallback((value: string) => {
    setSource(value)
    setOutput("")
    setMessage("")
    setStatus("idle")
  }, [])

  useEffect(() => () => {
    workerRef.current?.terminate()
    workerRef.current = null
    if (runTimeoutRef.current) clearTimeout(runTimeoutRef.current)
  }, [])

  function setSample(kind: "lua" | "roblox") {
    if (running) return
    changeSource(kind === "lua" ? EXAMPLE_LUA : EXAMPLE_ROBLOX)
    setFileName(kind === "lua" ? "example.lua" : "example.luau")
    setLuaVersion(kind === "lua" ? "Lua51" : "LuaU")
    setLogs([])
  }

  async function ingestFile(file: File | undefined) {
    if (!file || running) return
    if (file.size > 1024 * 1024) {
      setMessage("File exceeds the 1 MB browser limit.")
      setStatus("error")
      return
    }
    try {
      const value = await file.text()
      changeSource(value)
      setFileName(file.name)
      setLuaVersion(file.name.endsWith(".luau") ? "LuaU" : "Lua51")
      setLogs([])
      setMessage(`Loaded ${file.name}`)
    } catch {
      setMessage("Could not read that file.")
      setStatus("error")
    }
  }

  function stopRun() {
    workerRef.current?.terminate()
    workerRef.current = null
    if (runTimeoutRef.current) clearTimeout(runTimeoutRef.current)
    rejectRef.current?.(new Error("Obfuscation canceled."))
    rejectRef.current = null
    setStatus("idle")
    setMessage("Operation canceled.")
  }

  async function obfuscate() {
    if (running) return
    if (!source.trim()) {
      setStatus("error")
      setMessage("Add some Lua or Luau source code first.")
      document.getElementById("studio")?.scrollIntoView({ behavior: "smooth" })
      return
    }
    setStatus("running")
    setMessage("Running Prometheus in a local browser worker…")
    setOutput("")
    setLogs([])
    setElapsed(0)
    startedRef.current = performance.now()
    const id = ++requestRef.current
    const worker = new Worker(new URL("./worker/prometheus.worker.ts", import.meta.url), { type: "module" })
    workerRef.current = worker
    try {
      const result = await new Promise<PrometheusResult>((resolve, reject) => {
        rejectRef.current = reject
        worker.onmessage = (event: MessageEvent<WorkerResponse>) => {
          const response = event.data
          if (response.id !== id) return
          if (response.type === "log") {
            setLogs((current) => [...current, response.log])
            return
          }
          resolve(response.result)
        }
        worker.onerror = (event) => {
          reject(new Error(event.message || "The obfuscation worker encountered an error."))
        }
        const request: WorkerRequest = {
          id,
          action: "obfuscate",
          options: { source, filename: fileName, preset, luaVersion, prettyPrint, seed },
        }
        worker.postMessage(request)
        runTimeoutRef.current = setTimeout(() => reject(new Error("The job exceeded the 120-second limit. Try a smaller script or lighter preset.")), WORKER_TIMEOUT_MS)
      })
      if (workerRef.current !== worker) return
      setElapsed(Math.round(performance.now() - startedRef.current))
      setLogs(result.logs)
      if (result.ok) {
        setOutput(result.output)
        setStatus("done")
        setMessage(`Build complete. ${formatBytes(result.output.length)} of obfuscated Lua generated.`)
      } else {
        setStatus("error")
        setMessage(result.error || "Obfuscation failed. Check the diagnostic log.")
        setShowLog(true)
      }
    } catch (error) {
      if (workerRef.current !== worker) return
      setStatus("error")
      setMessage(error instanceof Error ? error.message : "Unknown obfuscation error")
      setShowLog(true)
    } finally {
      worker.terminate()
      if (workerRef.current === worker) workerRef.current = null
      rejectRef.current = null
      if (runTimeoutRef.current) clearTimeout(runTimeoutRef.current)
    }
  }

  async function copyOutput() {
    if (!output) return
    try {
      await navigator.clipboard.writeText(output)
      setCopied(true)
      setMessage("Copied protected source to clipboard.")
      window.setTimeout(() => setCopied(false), 1800)
    } catch {
      setMessage("Clipboard permission denied. Select the output and copy manually.")
    }
  }

  function downloadOutput() {
    if (!output) return
    const base = fileName.replace(/\.(lua|luau|txt)$/i, "").replace(/[^a-zA-Z0-9_.-]/g, "_") || "script"
    saveFile(output, base + ".obfuscated.lua")
  }

  function goToStudio() {
    setMobileMenu(false)
    document.getElementById("studio")?.scrollIntoView({ behavior: "smooth" })
  }

  return <div id="top" className="site">
    <div className="page-glow" aria-hidden="true" />
    <header className="site-header">
      <div className="nav-container">
        <Brand onClick={() => setMobileMenu(false)}/>
        <nav className={`nav-links ${mobileMenu ? "open" : ""}`} aria-label="Main navigation">
          <a href="#features" onClick={() => setMobileMenu(false)}>Features</a>
          <a href="#how-it-works" onClick={() => setMobileMenu(false)}>How it works</a>
          <a href="#studio" onClick={() => setMobileMenu(false)}>Obfuscator</a>
          <a href="https://github.com/prometheus-lua/Prometheus" target="_blank" rel="noopener noreferrer">Open source <ExternalLink size={13}/></a>
        </nav>
        <div className="nav-actions">
          <span className="nav-privacy"><span className="status-dot" /> 100% browser-based</span>
          <button type="button" className="btn btn-nav" onClick={goToStudio}>Launch studio <ArrowUpRight size={16}/></button>
          <button type="button" className="mobile-menu" onClick={() => setMobileMenu(!mobileMenu)} aria-label={mobileMenu ? "Close menu" : "Open menu"} aria-expanded={mobileMenu}>{mobileMenu ? <X size={21}/> : <Menu size={21}/>}</button>
        </div>
      </div>
    </header>

    <main>
      <section className="hero section-container" aria-labelledby="hero-heading">
        <div className="hero-copy">
          <div className="eyebrow"><span className="pulse-dot"/> THE MODERN LUA OBFUSCATOR <span className="eyebrow-line"/></div>
          <h1 id="hero-heading">Your code.<br/><span className="hero-highlight">Their headache<span className="hero-period">.</span></span></h1>
          <p className="hero-subtitle">Make your Lua and Luau projects harder to reverse-engineer with a real AST-based protection pipeline. Powered by Prometheus. Built for developers.</p>
          <div className="hero-actions">
            <button type="button" className="btn btn-primary btn-large" onClick={goToStudio}>Start obfuscating <ArrowUpRight size={19}/></button>
            <a href="#features" className="btn btn-outline btn-large">Explore features <ArrowDown size={17}/></a>
          </div>
          <div className="hero-trust"><span className="trust-icon"><ShieldCheck size={16}/></span> Your source stays on your device. No uploads. No accounts.</div>
        </div>
        <div className="hero-visual" aria-label="Code protection preview">
          <div className="hero-visual-glow"/>
          <div className="floating-pill floating-pill-top"><span className="pill-ring"><Shield size={16}/></span> PROMETHEUS ENGINE <span className="pill-active"/></div>
          <div className="preview-window">
            <div className="preview-topbar"><span className="mac-dots"><i/><i/><i/></span><span><FileCode2 size={13}/> main.luau</span><span className="preview-top-right"><Check size={12}/> Ready</span></div>
            <div className="preview-code"><div><b>01</b><span className="syntax-purple">local</span> <span className="syntax-white">secret</span> <span className="syntax-dim">=</span> <span className="syntax-yellow">"hello world"</span></div><div><b>02</b><span className="syntax-purple">local function</span> <span className="syntax-blue">protect</span><span className="syntax-white">(value)</span></div><div><b>03</b><span className="syntax-purple">  return</span> <span className="syntax-white">string.reverse(value)</span></div><div><b>04</b><span className="syntax-purple">end</span></div><div><b>05</b><span className="syntax-blue">print</span><span className="syntax-white">(protect(secret))</span></div><div className="code-gap"><b>06</b><span className="syntax-dim">-- applying protection…</span></div><div className="code-separator"><span>◆</span> KERSCRYPT / PROTECTED OUTPUT</div><div><b>07</b><span className="syntax-neon">local</span> <span className="syntax-dim">_0x7F9a=...</span></div><div><b>08</b><span className="syntax-dim">function _0x88a3(...)</span></div><div><b>09</b><span className="syntax-dim">  local _0x3ad=...</span></div><div><b>10</b><span className="syntax-dim">end</span> <span className="syntax-neon">-- protected</span></div></div>
            <div className="preview-footer"><span><span className="status-dot"/> Transformation complete</span><span>LuaU · Strong</span></div>
          </div>
          <div className="floating-pill floating-pill-bottom"><span className="fingerprint"><Fingerprint size={20}/></span><span><strong>Source protection</strong><small>Advanced AST transforms</small></span><CheckCircle2 size={21} className="lime"/></div>
        </div>
      </section>

      <section className="metrics-section section-container" aria-label="Platform capabilities">
        <div className="metric"><span className="metric-icon"><LockKeyhole size={17}/></span><span><strong>Local-first</strong><small>Private processing</small></span></div>
        <div className="metric"><span className="metric-icon"><Layers3 size={17}/></span><span><strong>4 protection modes</strong><small>From Minify to Strong</small></span></div>
        <div className="metric"><span className="metric-icon"><Code2 size={17}/></span><span><strong>Lua + Luau</strong><small>Developer focused</small></span></div>
        <div className="metric"><span className="metric-icon"><Zap size={17}/></span><span><strong>Real Prometheus</strong><small>Open-source engine</small></span></div>
      </section>

      <section className="feature-section section-container" id="features">
        <div className="section-heading-row"><div><SmallTag style="kicker">WHY KERSCRYPT</SmallTag><h2>Protection with<br/><span className="muted-title">real depth.</span></h2></div><p>No fake security sliders. No toy string scrambler. KersCrypt integrates the real Prometheus obfuscation pipeline into a clean workspace.</p></div>
        <div className="feature-grid">
          <article className="feature-card feature-main"><div className="feature-card-top"><span className="icon-tile"><ShieldCheck size={22}/></span><span className="card-index">01 / PROTECTION</span></div><div className="feature-lines"><i/><i/><i/><i/><i/></div><h3>Built for harder analysis.</h3><p>Advanced transformations from Prometheus—including its Strong preset and virtualization-based protections—make output substantially less readable.</p><a href="#studio" onClick={(e) => { e.preventDefault(); goToStudio() }} className="feature-link">Explore protection <ArrowUpRight size={16}/></a></article>
          <article className="feature-card"><div className="feature-card-top"><span className="icon-tile"><LockKeyhole size={22}/></span><span className="card-index">02 / PRIVACY</span></div><div className="privacy-art"><div className="privacy-ring"><LockKeyhole size={38}/></div><div className="privacy-arc arc-one"/><div className="privacy-arc arc-two"/></div><h3>Your source stays yours.</h3><p>Everything runs in your browser using WebAssembly. Your code isn't submitted to a KersCrypt server.</p></article>
          <article className="feature-card"><div className="feature-card-top"><span className="icon-tile"><SlidersHorizontal size={22}/></span><span className="card-index">03 / CONTROL</span></div><div className="preset-preview"><span className="selected-preset"><i/> STRONG</span><span>MEDIUM</span><span>WEAK</span><span>MINIFY</span></div><h3>You choose the strength.</h3><p>Switch between four presets, Lua targets, reproducible build seeds, and source formatting options.</p></article>
        </div>
      </section>

      <section className="studio-section" id="studio">
        <div className="section-container">
          <div className="studio-title-row"><div><SmallTag style="kicker">THE STUDIO</SmallTag><h2>Built to <span className="lime">protect.</span><br/>Ready to ship.</h2><p>Your script. Your settings. One click to obfuscate.</p></div><span className="studio-live"><span className="status-dot"/> PROCESSING LOCALLY</span></div>

          <div className="studio-shell">
            <div className="studio-header"><div className="studio-header-left"><span className="studio-hex"><Braces size={19}/></span><div><strong>KersCrypt Studio</strong><small>Lua / Luau Obfuscation Workspace</small></div></div><div className="studio-header-right"><span className="engine-state"><span className="status-dot"/> Engine online</span><span className="studio-version">PROMETHEUS CORE</span></div></div>
            <div className="studio-configuration">
              <div className="config-group"><label htmlFor="preset">PROTECTION PRESET</label><div className="control-select"><Shield size={16}/><select id="preset" value={preset} onChange={(e) => setPreset(e.target.value as PresetName)} disabled={running}>{Object.keys(PRESET_DETAILS).map((p) => <option key={p} value={p}>{p}</option>)}</select><ChevronDown size={15}/></div></div>
              <div className="config-group"><label htmlFor="dialect">LUA DIALECT</label><div className="control-select"><Code2 size={16}/><select id="dialect" value={luaVersion} onChange={(e) => setLuaVersion(e.target.value as LuaVersion)} disabled={running}><option value="Lua51">Lua 5.1</option><option value="LuaU">Roblox Luau</option></select><ChevronDown size={15}/></div></div>
              <div className="config-group config-strength"><label>PROTECTION LEVEL</label><div className="strength-indicator"><span className="strength-bars">{[1,2,3,4].map((s) => <i key={s} className={s <= PRESET_DETAILS[preset].strength ? "filled" : ""}/>)}</span><span>{PRESET_DETAILS[preset].subtitle}</span></div></div>
              <button type="button" className={`advanced-toggle ${showAdvanced ? "selected" : ""}`} onClick={() => setShowAdvanced(!showAdvanced)} aria-expanded={showAdvanced}><SlidersHorizontal size={16}/> Advanced <ChevronDown size={14} className={showAdvanced ? "rotate" : ""}/></button>
            </div>
            {showAdvanced && <div className="advanced-panel"><label className="check-row"><input type="checkbox" checked={prettyPrint} onChange={(e) => setPrettyPrint(e.target.checked)} disabled={running}/><span><strong>Pretty-print output</strong><small>Readable formatting; may increase file size</small></span></label><div className="seed-row"><div><strong>Deterministic seed</strong><small>Reuse to reproduce a build</small></div><input type="number" min="1" max="2147483647" value={seed} onChange={(e) => setSeed(Math.max(1,Math.floor(Number(e.target.value) || 1)))} disabled={running}/><button type="button" title="Regenerate seed" className="icon-button" onClick={() => setSeed(randomSeed())} disabled={running}><RefreshCcw size={16}/></button></div></div>}
            <div className="editor-grid">
              <div className="code-pane"><div className="pane-header"><div className="pane-name"><span className="pane-dot source-dot"/><span>INPUT</span><small>{fileName}</small></div><div className="pane-actions"><button type="button" onClick={() => setSample(luaVersion === "LuaU" ? "roblox" : "lua")} disabled={running} title="Load sample script"><RefreshCcw size={14}/><span>Example</span></button><button type="button" onClick={() => inputFileRef.current?.click()} disabled={running}><Upload size={14}/><span>Upload</span></button></div></div><div className={`editor-surface ${isDragging ? "dragging" : ""}`} onDragOver={(e) => { e.preventDefault(); setIsDragging(true) }} onDragLeave={(e) => { e.preventDefault(); setIsDragging(false) }} onDrop={(e) => { e.preventDefault(); setIsDragging(false); void ingestFile(e.dataTransfer.files[0]) }}><CodeEditor className="editor-component" label="Source code editor" value={source} onChange={changeSource} readOnly={running}/><input ref={inputFileRef} type="file" accept=".lua,.luau,.txt,text/plain" hidden onChange={(e) => { void ingestFile(e.target.files?.[0]); e.currentTarget.value = "" }}/></div><div className="pane-footer"><span><Terminal size={13}/> Editable source</span><span>{source.split("\n").length} lines · {formatBytes(new TextEncoder().encode(source).length)}</span></div></div>
              <div className="code-pane"><div className="pane-header"><div className="pane-name"><span className="pane-dot output-dot"/><span>OUTPUT</span><small>{output ? "protected.lua" : "awaiting build"}</small></div><div className="pane-actions"><button type="button" onClick={() => void copyOutput()} disabled={!output}>{copied ? <Check size={14}/> : <Copy size={14}/>}<span>{copied ? "Copied" : "Copy"}</span></button><button type="button" onClick={downloadOutput} disabled={!output}><Download size={14}/><span>Export</span></button></div></div><div className="editor-surface output-surface"><CodeEditor className="editor-component" label="Protected source code" value={output} readOnly/>{!output && <div className="empty-output"><div className="empty-symbol"><ShieldCheck size={32}/></div><strong>Protected code appears here</strong><span>Configure your options and run the obfuscator to generate output.</span></div>}</div><div className="pane-footer"><span><ShieldCheck size={13}/> {output ? "Obfuscated source" : "Waiting for input"}</span><span>{output ? `${output.split("\n").length} lines · ${formatBytes(new TextEncoder().encode(output).length)}` : "No output yet"}</span></div></div>
            </div>
            <div className="studio-runbar"><div className="run-info"><div className="run-info-icon"><WandSparkles size={18}/></div><div><strong>{status === "done" ? "Build completed successfully" : status === "error" ? "Check your script" : running ? "Protecting your code…" : "Ready to obfuscate"}</strong><span>{message || PRESET_DETAILS[preset].detail}</span></div></div><div className="run-actions">{status === "done" && <span className="elapsed"><Clock3 size={14}/> {(elapsed/1000).toFixed(2)}s</span>}{running ? <button type="button" className="btn btn-cancel" onClick={stopRun}><X size={17}/> Cancel</button> : <button type="button" className="btn btn-primary btn-run" onClick={() => void obfuscate()}><Zap size={18} fill="currentColor"/> Obfuscate now <ArrowRight size={17}/></button>}</div></div>
            {logs.length > 0 && <div className="log-section"><button type="button" className="log-toggle" onClick={() => setShowLog(!showLog)} aria-expanded={showLog}><Terminal size={15}/> Build log ({logs.length} entries)<ChevronDown size={15} className={showLog ? "rotate" : ""}/></button>{showLog && <div className="log-entries">{logs.slice(-50).map((entry,i) => <p key={i} className={`log-${entry.level}`}><span>[{entry.level}]</span> {entry.message}</p>)}</div>}</div>}
          </div>
          <div className="studio-under"><span><LockKeyhole size={14}/> Source code processes locally. No server upload.</span><span><CircleHelp size={14}/> Luau support varies by language feature. Test generated scripts.</span></div>
        </div>
      </section>

      <section className="workflow-section section-container" id="how-it-works"><div className="workflow-intro"><SmallTag style="kicker">THE WORKFLOW</SmallTag><h2>Three steps.<br/><span className="muted-title">One protected build.</span></h2><p>Skip the setup and get straight to shipping your project.</p></div><div className="workflow-steps"><div className="workflow-step"><span className="step-num">01</span><span className="step-icon"><FileCode2 size={23}/></span><h3>Drop in your script</h3><p>Paste source or upload a .lua / .luau file. Code stays in your browser.</p></div><div className="step-connector"><ArrowRight size={20}/></div><div className="workflow-step"><span className="step-num">02</span><span className="step-icon"><Gauge size={23}/></span><h3>Dial in protection</h3><p>Choose a Prometheus preset and your Lua target, then run the build.</p></div><div className="step-connector"><ArrowRight size={20}/></div><div className="workflow-step"><span className="step-num">03</span><span className="step-icon"><Download size={23}/></span><h3>Export your output</h3><p>Copy the result or download the generated .lua file for testing.</p></div></div></section>

      <section className="faq-section section-container" id="faq"><div><SmallTag style="kicker">GOOD TO KNOW</SmallTag><h2>Questions?<br/><span className="muted-title">Covered.</span></h2><p>Technical protection without the mystery.</p></div><div className="faq-list"><details><summary>Is KersCrypt actually using Prometheus? <ChevronDown size={20}/></summary><p>Yes. The obfuscation workspace uses the open-source Prometheus transformation pipeline running inside a WebAssembly Lua runtime. <a href="https://github.com/prometheus-lua/Prometheus" target="_blank" rel="noopener noreferrer">View the source engine <ArrowUpRight size={13}/></a></p></details><details><summary>Does my script get uploaded? <ChevronDown size={20}/></summary><p>No. Obfuscation happens locally in your browser. Avoid sharing screenshots, code snippets, or generated share links if they contain private source.</p></details><details><summary>Will it work with Roblox Luau? <ChevronDown size={20}/></summary><p>Prometheus provides a LuaU target, but compatibility isn't guaranteed for every Roblox or typed Luau feature. Always test your output inside your target runtime before releasing it.</p></details><details><summary>Is my obfuscated code impossible to reverse? <ChevronDown size={20}/></summary><p>No obfuscator can promise that. Obfuscation raises the effort needed to inspect or modify source but isn't encryption or an access-control system.</p></details></div></section>

      <section className="bottom-cta section-container"><div className="cta-glow"/><div className="cta-top"><div><SmallTag style="kicker">READY WHEN YOU ARE</SmallTag><h2>Your next release<br/>deserves protection<span className="lime">.</span></h2><p>One workspace. Real Prometheus protection. No account needed.</p></div><button type="button" onClick={goToStudio} className="btn btn-primary btn-large">Launch KersCrypt <ArrowUpRight size={19}/></button></div><div className="cta-bottom"><span><ShieldCheck size={16}/> Privacy first</span><span><Code2 size={16}/> Built for developers</span><span><Sparkles size={16}/> No registration</span></div></section>
    </main>

    <footer className="site-footer"><div className="section-container footer-main"><div className="footer-about"><Brand/><p>The modern workspace for Lua and Luau obfuscation. Your code stays yours.</p></div><div className="footer-col"><strong>PRODUCT</strong><a href="#features">Features</a><a href="#studio">Obfuscator</a><a href="#how-it-works">How it works</a></div><div className="footer-col"><strong>RESOURCES</strong><a href="https://github.com/prometheus-lua/Prometheus" target="_blank" rel="noopener noreferrer">Prometheus source <ArrowUpRight size={13}/></a><a href="https://github.com/prometheus-lua/Prometheus/blob/master/LICENSE" target="_blank" rel="noopener noreferrer">Engine license <ArrowUpRight size={13}/></a><a href="#faq">FAQ</a></div></div><div className="section-container footer-bottom"><span>© 2026 KersCrypt. Independent developer project.</span><span>Powered by <a href="https://github.com/prometheus-lua/Prometheus" target="_blank" rel="noopener noreferrer">Prometheus</a> · Open-source attribution preserved</span></div></footer>
  </div>
}
