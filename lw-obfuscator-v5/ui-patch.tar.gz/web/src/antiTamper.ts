/** Compatibility-safe subset of the user-supplied antiTamperPromFork.lua.txt.
 * This is a runtime tripwire, not cryptographic authentication.
 * Avoids debug.getinfo, bitwise ~ (Lua 5.3-only), global metatable writes,
 * and randomseed side effects that break Lua 5.1 or Roblox Luau.
 */
const MODULUS = 2147483647

function pseudoRandom(seed: number): () => number {
  let state = (Math.floor(seed) >>> 0) || 1
  return () => {
    state ^= state << 13
    state ^= state >>> 17
    state ^= state << 5
    return state >>> 0
  }
}

function digest(text: string): number {
  let value = 0
  for (let i = 0; i < text.length; i++) {
    value = (value * 131 + text.charCodeAt(i)) % MODULUS
  }
  return value
}

export function addAntiTamper(source: string, seed: number): string {
  const random = pseudoRandom(seed)
  const token = Array.from({ length: 24 }, () => String.fromCharCode(33 + random() % 94)).join("")
  const literal = '"' + Array.from(token, char => '\\' + String(char.charCodeAt(0)).padStart(3, '0')).join("") + '"'
  const expected = digest(token)

  const guard = [
    'do',
    '  -- LW Obfuscator runtime integrity tripwire (compatibility mode).',
    '  local function __lw_runtime_integrity_check()',
    '    if type(type) ~= "function" or type(pcall) ~= "function" or type(error) ~= "function" then return false end',
    '    if type(string) ~= "table" or type(string.byte) ~= "function" or type(string.char) ~= "function" then return false end',
    '    if type(math) ~= "table" or type(math.floor) ~= "function" then return false end',
    '    if string.char(76, 87) ~= "LW" or string.byte("LW", 2) ~= 87 then return false end',
    '    if math.floor(3.75) ~= 3 then return false end',
    '    local __lw_probe = ' + literal,
    '    local __lw_hash = 0',
    '    for __lw_i = 1, #__lw_probe do',
    '      __lw_hash = (__lw_hash * 131 + string.byte(__lw_probe, __lw_i)) % 2147483647',
    '    end',
    '    return __lw_hash == ' + expected,
    '  end',
    '  local __lw_ok, __lw_valid = pcall(__lw_runtime_integrity_check)',
    '  if not __lw_ok or not __lw_valid then error("LW Obfuscator: integrity check failed", 0) end',
    'end',
    '',
  ].join("\n")

  const header = source.match(/^(\uFEFF?(?:--![^\r\n]*(?:\r?\n|$))*)/)?.[0] ?? ""
  return header + guard + source.slice(header.length)
}
