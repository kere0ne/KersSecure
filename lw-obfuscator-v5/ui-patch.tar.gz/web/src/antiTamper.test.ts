import { describe, expect, it } from "vitest"
import { addAntiTamper } from "./antiTamper"
import { runLuaScript, runPrometheus } from "./worker/prometheusRunner"

const program = 'local a = "LW"; print(a .. "-ok")'

describe("LW runtime integrity guard", () => {
  it("preserves execution and stdout", async () => {
    const result = await runLuaScript({source: addAntiTamper(program, 12345), filename: "input.lua"})
    if (!result.ok) throw new Error(result.error)
    expect(result.logs.map(l => l.message).join(" ")).toContain("LW-ok")
  }, 15000)

  it("is reproducible, seed-specific and avoids incompatible APIs", () => {
    const one = addAntiTamper(program, 12345)
    expect(one).toBe(addAntiTamper(program,12345))
    expect(one).not.toBe(addAntiTamper(program,12346))
    expect(one).not.toContain("debug.getinfo")
    expect(one).not.toContain("setmetatable(_G")
    expect(addAntiTamper("--!strict\n" + program, 123).startsWith("--!strict\ndo\n")).toBe(true)
  })

  it("rejects tampering with integrity marker", async () => {
    const good = addAntiTamper(program, 12345)
    const changed = good.replace(/\\\d{3}/, '\\000')
    const result = await runLuaScript({source: changed, filename: "changed.lua"})
    if (result.ok) throw new Error("Tampered code unexpectedly succeeded")
    expect(result.error).toContain("integrity check failed")
  }, 15000)

  it.each(["Lua51", "LuaU"] as const)("passes Prometheus Strong + executes in %s", async (luaVersion) => {
    const src = program
    const result = await runPrometheus({source: src, filename: "input.lua", preset: "Strong", luaVersion, prettyPrint: false, seed: 8675309})
    if (!result.ok) throw new Error(result.error)
    expect(result.output.length).toBeGreaterThan(100)
    const executed = await runLuaScript({source: addAntiTamper(result.output, 8675309), filename: "output.lua"})
    if (!executed.ok) throw new Error(executed.error)
    expect(executed.logs.map(l => l.message).join(" ")).toContain("LW-ok")
  }, 30000)
})
